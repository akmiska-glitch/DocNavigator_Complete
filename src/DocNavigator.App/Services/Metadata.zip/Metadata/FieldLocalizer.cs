using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;

namespace DocNavigator.App.Services.Metadata
{
    /// <summary>
    /// Локализация заголовков КОЛОНОК по .desc:
    /// - Для content-таблиц: ищем блок с Table == system table name (без учёта регистра) в коллекции "Contents" (или похожих),
    ///   затем внутри поля (Fields) и сопоставляем field/@id -> подпись (desc/documentation/caption/label/...).
    /// - Для fieldset-таблиц: аналогично, ищем коллекции, содержащие "Fieldset" в названии.
    /// - Если найти структурированные блоки не удалось, пробуем словарь FieldCaptions (id->caption).
    /// </summary>
    public static class FieldLocalizer
    {
        /// <summary>
        /// Основной вызов: таблица уже знает своё системное имя (table.TableName).
        /// </summary>
        public static void ApplyDisplayNames(DataTable table, object? descriptorMeta)
            => ApplyDisplayNames(table, descriptorMeta, table?.TableName);

        /// <summary>
        /// Прямой вызов с явным указанием системного имени таблицы (если TableName не задан корректно).
        /// </summary>
        public static void ApplyDisplayNames(DataTable table, object? descriptorMeta, string? systemTableName)
        {
            if (table == null || table.Columns.Count == 0 || descriptorMeta == null)
                return;

            var map = BuildFieldMapForTable(descriptorMeta, systemTableName ?? table.TableName);
            if (map == null || map.Count == 0)
                return;

            // Переименовываем колонки. Сохраняем порядок. При необходимости — уникализируем.
            var used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (DataColumn col in table.Columns)
            {
                var id = col.ColumnName; // имя из SQL
                var key = id.ToLowerInvariant();
                if (map.TryGetValue(key, out var ru) && !string.IsNullOrWhiteSpace(ru))
                {
                    var final = MakeUnique(ru, used);
                    col.ColumnName = final;
                }
                else
                {
                    used.Add(col.ColumnName);
                }
            }
        }

        // --------- Вспомогательные ---------

        private static IDictionary<string, string>? BuildFieldMapForTable(object meta, string? systemTableName)
        {
            if (!string.IsNullOrWhiteSpace(systemTableName))
            {
                // 1) Ищем коллекцию "Contents" или любую, где элементы имеют свойства Table + Fields
                var dict = TryFromCollections(meta, systemTableName!, preferFieldset: false);
                if (dict != null && dict.Count > 0) return dict;

                // 2) Ищем коллекции Fieldset*
                dict = TryFromCollections(meta, systemTableName!, preferFieldset: true);
                if (dict != null && dict.Count > 0) return dict;
            }

            // 3) Фолбэк: словарь FieldCaptions (id -> caption)
            var fc = meta.GetType().GetProperty("FieldCaptions", BindingFlags.Public | BindingFlags.Instance);
            if (fc != null)
            {
                if (fc.GetValue(meta) is IDictionary raw)
                {
                    var res = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                    foreach (var key in raw.Keys)
                    {
                        if (key is string id)
                        {
                            var val = raw[key]?.ToString();
                            if (!string.IsNullOrWhiteSpace(id) && !string.IsNullOrWhiteSpace(val))
                                res[id.ToLowerInvariant()] = val!;
                        }
                    }
                    if (res.Count > 0) return res;
                }
            }

            return new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        }

        private static Dictionary<string, string>? TryFromCollections(object meta, string systemTableName, bool preferFieldset)
        {
            // Собираем все публичные перечислимые свойства
            var props = meta.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance)
                            .Where(p => typeof(IEnumerable).IsAssignableFrom(p.PropertyType) && p.PropertyType != typeof(string));

            // Приоритет: если preferFieldset, то сначала свойства с именем, содержащим "fieldset"
            IEnumerable<PropertyInfo> ordered;
            if (preferFieldset)
                ordered = props.OrderByDescending(p => p.Name.IndexOf("fieldset", StringComparison.OrdinalIgnoreCase) >= 0);
            else
                ordered = props.OrderByDescending(p => p.Name.IndexOf("content", StringComparison.OrdinalIgnoreCase) >= 0);

            foreach (var p in ordered)
            {
                var enumerable = p.GetValue(meta) as IEnumerable;
                if (enumerable == null) continue;

                foreach (var item in enumerable)
                {
                    // У элемента пытаемся прочитать Table и Fields
                    var tableName = ReadStringProp(item, "Table");
                    if (string.IsNullOrWhiteSpace(tableName))
                        continue;

                    if (!tableName.Equals(systemTableName, StringComparison.OrdinalIgnoreCase))
                        continue;

                    var fields = ReadEnumerableProp(item, "Fields");
                    if (fields == null) continue;

                    var res = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                    foreach (var f in fields)
                    {
                        var id = ReadStringProp(f, "Id");
                        if (string.IsNullOrWhiteSpace(id)) continue;

                        // Приоритет подписей: desc > documentation > caption > label > title > name
                        var ru = ReadStringProp(f, "Desc")
                                 ?? ReadStringProp(f, "Documentation")
                                 ?? ReadStringProp(f, "Caption")
                                 ?? ReadStringProp(f, "Label")
                                 ?? ReadStringProp(f, "Title")
                                 ?? ReadStringProp(f, "Name");

                        if (!string.IsNullOrWhiteSpace(ru))
                            res[id.ToLowerInvariant()] = ru!;
                    }

                    if (res.Count > 0) return res;
                }
            }

            return null;
        }

        private static IEnumerable? ReadEnumerableProp(object obj, string propName)
        {
            var p = obj.GetType().GetProperty(propName, BindingFlags.Public | BindingFlags.Instance);
            return p?.GetValue(obj) as IEnumerable;
        }

        private static string? ReadStringProp(object obj, string propName)
        {
            var p = obj.GetType().GetProperty(propName, BindingFlags.Public | BindingFlags.Instance);
            var v = p?.GetValue(obj);
            return v?.ToString();
        }

        private static string MakeUnique(string baseName, HashSet<string> used)
        {
            if (!used.Contains(baseName))
            {
                used.Add(baseName);
                return baseName;
            }
            int i = 2;
            while (true)
            {
                var cand = $"{baseName} ({i})";
                if (!used.Contains(cand))
                {
                    used.Add(cand);
                    return cand;
                }
                i++;
            }
        }
    }
}